package org.lwjgl.opengl;

import org.lwjgl.opengl.EXTABGR;

public class EXTAbgr {
	public final static int GL_ABGR_EXT = EXTABGR.GL_ABGR_EXT;
}
