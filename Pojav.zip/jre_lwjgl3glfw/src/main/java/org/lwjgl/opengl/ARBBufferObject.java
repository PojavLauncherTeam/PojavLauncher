package org.lwjgl.opengl;

public class ARBBufferObject extends ARBVertexBufferObject
{
}
