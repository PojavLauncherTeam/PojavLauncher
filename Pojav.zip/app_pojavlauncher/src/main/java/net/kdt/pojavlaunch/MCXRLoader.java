package net.kdt.pojavlaunch;

import android.app.Activity;
import android.content.Context;

public class MCXRLoader {
    public static native void setContext(Context ctx);

    public static native long getContextPtr();

    public static native void setActivityPtr(MainActivity activity);

    static {
        System.loadLibrary("mcxr_loader");
    }

    public static native void launch(MainActivity activity);
}
