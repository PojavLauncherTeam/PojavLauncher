package net.kdt.pojavlaunch.value;

public class MinecraftLibraryArtifact extends MinecraftClientInfo
{
	public String path;
}
