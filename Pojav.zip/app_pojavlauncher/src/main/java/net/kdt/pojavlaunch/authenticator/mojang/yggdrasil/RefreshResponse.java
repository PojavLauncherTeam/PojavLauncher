package net.kdt.pojavlaunch.authenticator.mojang.yggdrasil;

import java.util.UUID;

public class RefreshResponse {
    public String accessToken;
    public UUID clientToken;
    public Profile selectedProfile;
}

