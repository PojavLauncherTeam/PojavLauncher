package net.kdt.pojavlaunch;

public class JAssetInfo
{
	public String hash;
    public int size;
}
