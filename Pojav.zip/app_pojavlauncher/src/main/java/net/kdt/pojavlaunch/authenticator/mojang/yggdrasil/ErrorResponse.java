package net.kdt.pojavlaunch.authenticator.mojang.yggdrasil;

public class ErrorResponse {
    public String cause;
    public String error;
    public String errorMessage;
}

