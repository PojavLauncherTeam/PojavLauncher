package net.kdt.pojavlaunch.authenticator.mojang.yggdrasil;

public class Profile {
    public String id;
    public boolean legacy;
    public String name;
}

